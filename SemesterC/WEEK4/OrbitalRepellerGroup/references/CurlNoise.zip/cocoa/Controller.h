#import <Cocoa/Cocoa.h>

@interface Controller : NSWindowController {
}

- (IBAction)changeTransparency:(id)sender;

@end
